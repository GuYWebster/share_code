//
//  JobProcessorTests.swift
//  JobProcessorTests
//
//  Created by Volodymyr Demkovskyi on 20.06.2023.
//

import XCTest
@testable import JobProcessor

final class JobProcessorTests: XCTestCase {
    
    var jobProcessor: JobProcessor!
    
    override func setUp() {
        super.setUp()
        jobProcessor = JobProcessor()
    }
    
    override func tearDown() {
        jobProcessor = nil
        super.tearDown()
    }
    
    func testJobGeneration() {
        jobProcessor.startProcessing()
        
        let expectation = XCTestExpectation(description: "Jobs generated")
        let maxCapacity = Constants.maximumCapacity
        
        jobProcessor.activeJobsUpdated = { activeJobs in
            if activeJobs.count < maxCapacity {
                expectation.fulfill()
            }
        }
        
        wait(for: [expectation], timeout: 3.0)
        XCTAssertLessThan(jobProcessor.activeJobs.count, maxCapacity, "Сapacity is greater than the allowable value")
    }
    
    func testMaximumCapacityReached() {
        let job = Job()
        jobProcessor.activeJobs = Array(repeating: job, count: Constants.maximumCapacity)
        
        jobProcessor.activeJobsUpdated = { activeJobs in
            XCTFail("activeJobsUpdated should not be called")
        }
        
        jobProcessor.startProcessing()
        
        XCTAssertEqual(jobProcessor.activeJobs.count, Constants.maximumCapacity)
    }
    
    func testCancelJob_JobRemoved() {
        // Arrange
        let job = Job()
        jobProcessor.activeJobs.append(job)
        
        // Act
        jobProcessor.cancelJob(job)
        
        // Assert
        XCTAssertTrue(jobProcessor.activeJobs.filter({ $0.id == job.id }).isEmpty, "Cancelled job should be removed from active jobs")
    }
    
    func testJobCancellation() {
        jobProcessor.startProcessing()
        
        let job = Job()
        jobProcessor.activeJobs.append(job)
        
        let initialJobCount = jobProcessor.activeJobs.count
        
        jobProcessor.cancelJob(job)
        
        XCTAssertEqual(jobProcessor.activeJobs.count, initialJobCount - 1, "Invalid value received")
        XCTAssertFalse(job.isActive, "Invalid value received")
    }
    
    func testJobCompletion() {
        let job = Job()
        jobProcessor.activeJobs.append(job)
        
        let initialJobCount = jobProcessor.activeJobs.count
        
        jobProcessor.jobCompleted(job)
        
        XCTAssertEqual(jobProcessor.activeJobs.count, initialJobCount - 1, "Invalid value received")
    }
    
}
