//
//  JobCell.swift
//  JobProcessor
//
//  Created by Volodymyr Demkovskyi on 20.06.2023.
//

import UIKit

final class JobCell: UITableViewCell {
    
    private var job: Job?
    var cancelJob: ((_ job: Job) -> Void)?
    
    @IBOutlet private weak var jobIDLabel: UILabel!
    @IBOutlet private weak var progressBar: UIProgressView!
    @IBOutlet private weak var cancelButton: UIButton!
    
    @IBAction private func cancelButtonPressed() {
        guard let job = self.job else { return }
        self.cancelButton.isEnabled = false
        self.cancelJob?(job)
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        self.progressBar.progress = 0
        self.jobIDLabel.text = nil
        self.cancelButton.isEnabled = true
    }
}

extension JobCell {
    func setupCell(_ with: Job) {
        self.job = with
        self.jobIDLabel.text = "Job ID: \n\(with.id)"
        self.job?.progressUpdateHandler = { [weak self] progress in
            DispatchQueue.main.async {
                self?.progressBar.progress = progress
            }
        }
    }
}
