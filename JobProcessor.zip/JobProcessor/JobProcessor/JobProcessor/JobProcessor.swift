//
//  JobProcessor.swift
//  JobProcessor
//
//  Created by Volodymyr Demkovskyi on 20.06.2023.
//

import Foundation

final class JobProcessor {
    
    var activeJobs: [Job] = []
    var activeJobsUpdated: (([Job]) -> Void)?
    
    func startProcessing() {
        Timer.scheduledTimer(timeInterval: Constants.jobGenerationInterval, target: self, selector: #selector(generateJobs), userInfo: nil, repeats: true)
    }
    
    @objc private func generateJobs() {
        guard activeJobs.count <= Constants.maximumCapacity else {
            debugPrint("Maximum capacity reached. New job rejected.")
            return
        }
        // Job generation and execution
        let job = Job()
        activeJobs.append(job)
        self.activeJobsUpdated?(activeJobs)
        debugPrint("New job generated. ID: \(job.id), Size: \(job.size) ms")
        debugPrint("Active jobs count: \(activeJobs.count)")
        
        DispatchQueue.global().async {
            self.executeJob(job)
        }
    }
    
    private func executeJob(_ job: Job) {
        let executionTime = DispatchTimeInterval.milliseconds(job.size)
        let totalExecutionTime = executionTime.dispatchTimeIntervalToTimeInterval()
        
        let updateStep = Float(Constants.progressUpdateInterval / totalExecutionTime)
        
        var elapsedTime: TimeInterval = 0.0
        
        while elapsedTime < totalExecutionTime {
            guard job.isActive else { return }
            Thread.sleep(forTimeInterval: Constants.progressUpdateInterval)
            elapsedTime += Constants.progressUpdateInterval
            job.progress += updateStep
            
            // Update progress bar
            job.updateProgress(job.progress)
        }
        
        jobCompleted(job)
    }
    
    
    
    func jobCompleted(_ job: Job) {
        guard  let index = activeJobs.firstIndex(where: { $0.id == job.id }) else { return }
        activeJobs.remove(at: index)
        print("Job completed. ID: \(job.id)")
        
        // User interface update
        self.activeJobsUpdated?(self.activeJobs)
    }
    
    func cancelJob(_ job: Job) {
        // Removing a task from active tasks and canceling execution
        guard  let index = activeJobs.firstIndex(where: { $0.id == job.id }) else { return }
        print("Job cancelled. ID: \(job.id)")
        activeJobs.remove(at: index)
        
        job.isActive = false
        // User interface update
        self.activeJobsUpdated?(self.activeJobs)
    }
}
