//
//  ReuseIdentifiable.swift
//  JobProcessor
//
//  Created by Volodymyr Demkovskyi on 20.06.2023.
//

import UIKit

public protocol ReuseIdentifiable {
    static var identifier: String { get }
}

public extension ReuseIdentifiable {
    static var identifier: String {
        String(describing: self)
    }
}
