//
//  NibLoadable.swift
//  JobProcessor
//
//  Created by Volodymyr Demkovskyi on 20.06.2023.
//

import UIKit

public protocol NibLoadable: AnyObject {
    static var nibName: String { get }

    static func nib(bundle: Bundle?) -> UINib
}

public extension NibLoadable {
    static var nibName: String {
        String(describing: self)
    }

    static func nib(bundle: Bundle? = nil) -> UINib {
        UINib(nibName: self.nibName, bundle: bundle)
    }
}

public extension NibLoadable where Self: UIView {
    func loadViewFromNib(bundle: Bundle? = nil) -> UIView {
        guard let view = UINib(
            nibName: Self.nibName,
            bundle: bundle
        ).instantiate(
            withOwner: self,
            options: nil
        ).first as? UIView else {
            fatalError("View can't be instantiated")
        }

        return view
    }
}

public extension NibLoadable where Self: UIViewController { }
