//
//  UITableViewCell+ReuseIdentifiable.swift
//  JobProcessor
//
//  Created by Volodymyr Demkovskyi on 20.06.2023.
//

import UIKit

extension UITableViewCell: ReuseIdentifiable { }
