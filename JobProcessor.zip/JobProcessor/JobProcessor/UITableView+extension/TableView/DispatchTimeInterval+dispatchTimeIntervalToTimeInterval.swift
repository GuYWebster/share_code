//
//  DispatchTimeInterval+dispatchTimeIntervalToTimeInterval.swift
//  JobProcessor
//
//  Created by Volodymyr Demkovskyi on 20.06.2023.
//

import UIKit

extension DispatchTimeInterval {
    func dispatchTimeIntervalToTimeInterval() -> TimeInterval {
        switch self {
        case .seconds(let value):
            return TimeInterval(value)
        case .milliseconds(let value):
            return TimeInterval(value) / 1000.0
        case .microseconds(let value):
            return TimeInterval(value) / 1_000_000.0
        case .nanoseconds(let value):
            return TimeInterval(value) / 1_000_000_000.0
        case .never:
            return .infinity
        @unknown default:
            fatalError("Unknown DispatchTimeInterval case.")
        }
    }
}

extension Array {
    func isValidIndex(_ index: Int) -> Bool {
        return index >= 0 && index < count
    }
}
