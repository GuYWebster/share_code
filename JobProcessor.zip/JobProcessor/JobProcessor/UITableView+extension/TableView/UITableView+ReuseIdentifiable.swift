//
//  UITableView+ReuseIdentifiable.swift
//  JobProcessor
//
//  Created by Volodymyr Demkovskyi on 20.06.2023.
//

import UIKit

public extension UITableView {
    func register<T: UITableViewCell>(type: T.Type, bundle: Bundle? = .main) {
        register(T.nib(bundle: bundle), forCellReuseIdentifier: T.identifier)
    }

    func registerClass<T: UITableViewCell>(type: T.Type) {
        register(T.self, forCellReuseIdentifier: T.identifier)
    }

}

extension UITableViewCell: NibLoadable { }
