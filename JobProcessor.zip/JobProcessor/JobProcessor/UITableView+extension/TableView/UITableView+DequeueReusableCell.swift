//
//  UITableView+DequeueReusableCell.swift
//  JobProcessor
//
//  Created by Volodymyr Demkovskyi on 20.06.2023.
//

import UIKit

public extension UITableView {
    func dequeueReusableCell<T: UITableViewCell>(for indexPath: IndexPath) -> T {
        // swiftlint:disable force_cast
        dequeueReusableCell(withIdentifier: T.identifier, for: indexPath) as! T
        // swiftlint:enable force_cast
    }

    func dequeueReusableHeaderFooterView<T: UITableViewHeaderFooterView>(for indexPath: IndexPath) -> T {
        // swiftlint:disable force_cast
        dequeueReusableHeaderFooterView(withIdentifier: T.identifier) as! T
        // swiftlint:enable force_cast
    }

}
