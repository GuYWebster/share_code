//
//  Constants.swift
//  JobProcessor
//
//  Created by Volodymyr Demkovskyi on 20.06.2023.
//

struct Constants {
    
    static let progressUpdateInterval = 0.1
    static let maximumCapacity = 20
    static let jobGenerationInterval = 2.0
    static let sizeOfJob = 100...5000
    
}
