//
//  Job.swift
//  JobProcessor
//
//  Created by Volodymyr Demkovskyi on 20.06.2023.
//

import Foundation

class Job {
    let id: String
    let size: Int
    var progress: Float = 0.0
    var progressUpdateHandler: ((Float) -> Void)?
    var isActive = true
    
    init() {
        self.id = UUID().uuidString
        self.size = Int.random(in: Constants.sizeOfJob)
    }
    
    func updateProgress(_ progress: Float) {
        self.progress = progress
        progressUpdateHandler?(progress)
    }
}
