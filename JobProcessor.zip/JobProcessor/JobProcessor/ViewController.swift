//
//  ViewController.swift
//  JobProcessor
//
//  Created by Volodymyr Demkovskyi on 20.06.2023.
//

import UIKit

final class ViewController: UIViewController {
    
    private var activeJobs: [Job] = []
    private let jobProcessor = JobProcessor()
    
    @IBOutlet private weak var tableView: UITableView! {
        didSet {
            tableView.dataSource = self
            tableView.delegate = self
            tableView.register(type: JobCell.self)
        }
    }
        
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupJobProcessor()
    }
}

private extension ViewController {
    
    func setupJobProcessor() {
        self.jobProcessor.activeJobsUpdated = { [weak self] jobs in
            self?.activeJobs = jobs
            DispatchQueue.main.async {
                self?.tableView.reloadData()
            }
        }
        jobProcessor.startProcessing()
    }
    
}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    
    // MARK: - UITableViewDataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return activeJobs.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard activeJobs.isValidIndex(indexPath.row) else { return UITableViewCell() }
        let cell: JobCell = tableView.dequeueReusableCell(for: indexPath)
        let job = activeJobs[indexPath.row]
        cell.setupCell(job)
        cell.cancelJob = { [weak self] job in
            self?.jobProcessor.cancelJob(job)
        }
        return cell
    }
    
    // MARK: - UITableViewDelegate
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return .cellHeight
    }
    
}

fileprivate extension CGFloat {
    static let cellHeight: CGFloat = 160
}
